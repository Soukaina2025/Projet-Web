
new Swiper(".wrapper", {
  loop: true,
  spaceBetween: 30,

  // Autoplay
  autoplay: {
    delay: 5000,
    disableOnInteraction: false,
    pauseOnMouseEnter: true,
  },

  // Pagination bullets
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
    dynamicBullets: true,
  },

  // Navigation arrows
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },

  // Responsive breakpoints
  breakpoints: {
    0: {
      slidesPerView: 1,
    },
    768: {
      slidesPerView: 2,
    },
    1024: {
      slidesPerView: 3,
    },
  },
});



document.addEventListener("DOMContentLoaded", function () {
    const toggleButton = document.getElementById("user-menu-toggle");
    const dropdownMenu = document.getElementById("user-action-menu");

    toggleButton.addEventListener("click", function (e) {
        e.preventDefault();
        dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none" : "block";
    });



    // Carousel navigation
    const carouselLinks = document.querySelectorAll('.carousel-navigation-link');
    carouselLinks.forEach(link => {
        link.addEventListener('click', function () {
            const targetId = this.getAttribute('data-carousel-target-id');
            const currentItem = document.querySelector('.carousel-item.active');
            if (currentItem) currentItem.classList.remove('active');

            const newItem = document.getElementById(targetId);
            if (newItem) newItem.classList.add('active');
        });
    });

    // Optional: close dropdown when clicking outside
    document.addEventListener("click", function (event) {
        if (!dropdownMenu.contains(event.target) && !toggleButton.contains(event.target)) {
            dropdownMenu.style.display = "none";
        }
    });
});


// Sélectionner le bouton, la barre de filtrage et les cartes
const toggleButton = document.getElementById('toggleSidebar');
const filterSidebar = document.getElementById('filterSidebar');
const cardList = document.querySelector('.card-list');

// Ajouter un événement au bouton pour afficher/masquer la barre de filtrage
toggleButton.addEventListener('click', () => {
    // Activer ou désactiver la classe active sur la barre de filtrage
    filterSidebar.classList.toggle('active');
    
    // Déplacer les cartes pour faire de la place à la barre de filtrage
    cardList.classList.toggle('shift');
});



// Masquer tous les sous-menus au chargement de la page
window.onload = function() {
  var submenus = document.querySelectorAll('.submenu');
  submenus.forEach(function(submenu) {
    submenu.style.display = 'none';
  });
};


document.addEventListener("DOMContentLoaded", function () {
    const toggleButton = document.getElementById("user-menu-toggle");
    const dropdownMenu = document.getElementById("user-action-menu");

    if (toggleButton && dropdownMenu) {
        toggleButton.addEventListener("click", function (e) {
            e.preventDefault();
            dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none" : "block";
        });

        // Fermer le menu en cliquant à l'extérieur
        document.addEventListener("click", function (event) {
            if (!dropdownMenu.contains(event.target) && !toggleButton.contains(event.target)) {
                dropdownMenu.style.display = "none";
            }
        });
    }
});


document.addEventListener('DOMContentLoaded', function() {
  const swiper = new Swiper('.swiper', {
      loop: true,
      spaceBetween: 30,
      autoplay: {
          delay: 2000,
          disableOnInteraction: false,
          pauseOnMouseEnter: true,
      },
      pagination: {
          el: '.swiper-pagination',
          clickable: true,
          dynamicBullets: true,
      },
      navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
      },
      breakpoints: {
          0: { slidesPerView: 1 },
          768: { slidesPerView: 2 },
          1024: { slidesPerView: 3 }
      }
  });

  // Masquer tous les sous-menus au chargement
  const submenus = document.querySelectorAll('.submenu');
  submenus.forEach(submenu => {
      submenu.style.display = 'none';
  });

  // Gestion du menu utilisateur
  const toggleButton = document.getElementById('dropdownUser');
  if (toggleButton) {
      toggleButton.addEventListener('click', function(e) {
          e.preventDefault();
          const dropdownMenu = document.querySelector('.dropdown-menu');
          if (dropdownMenu) {
              dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
          }
      });

      // Fermer le menu en cliquant à l'extérieur
      document.addEventListener('click', function(event) {
          const dropdownMenu = document.querySelector('.dropdown-menu');
          if (dropdownMenu && !toggleButton.contains(event.target) && !dropdownMenu.contains(event.target)) {
              dropdownMenu.style.display = 'none';
          }
      });
  }
});


// Fonction pour basculer l'affichage des sous-menus
function toggleMenu(menuId) {
  const submenu = document.getElementById(menuId);
  if (submenu) {
      submenu.style.display = submenu.style.display === 'block' ? 'none' : 'block';
  }
}


function incrementCounter(icon) {
  const countSpan = icon.nextElementSibling;
  if (countSpan) {
      let currentCount = parseInt(countSpan.textContent, 10) || 0;
      countSpan.textContent = currentCount + 1;
  }
}




