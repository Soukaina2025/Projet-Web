        document.addEventListener('DOMContentLoaded', function() {
            // Gestion de la connexion
            const loginForm = document.getElementById('studentLoginForm');
            
            loginForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Validation
                const studentId = document.getElementById('studentId').value.trim();
                const password = document.getElementById('password').value.trim();
                let isValid = true;
                
                // Réinitialiser les messages d'erreur
                document.querySelectorAll('.error-message').forEach(el => {
                    el.style.display = 'none';
                });
                
                // Validation de l'identifiant
                if (!studentId) {
                    document.getElementById('idError').style.display = 'block';
                    isValid = false;
                }
                
                // Validation du mot de passe
                if (!password) {
                    document.getElementById('passwordError').style.display = 'block';
                    isValid = false;
                }
                
                if (isValid) {
                    // Simulation de connexion
                    const submitBtn = this.querySelector('.submit-btn');
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Connexion en cours...';
                    
                    setTimeout(() => {
                        // Redirection après 1.5 secondes
                        window.location.href = 'dashboard.html';
                    }, 1500);
                }
            });
            
            // Gestion du mot de passe oublié
            const forgotPasswordLink = document.getElementById('forgotPasswordLink');
            const passwordResetModal = document.getElementById('passwordResetModal');
            const closeModal = document.querySelector('.close-modal');
            
            forgotPasswordLink.addEventListener('click', function(e) {
                e.preventDefault();
                passwordResetModal.style.display = 'block';
            });
            
            closeModal.addEventListener('click', function() {
                passwordResetModal.style.display = 'none';
            });
            
            window.addEventListener('click', function(e) {
                if (e.target === passwordResetModal) {
                    passwordResetModal.style.display = 'none';
                }
            });
            
            // Gestion du formulaire de réinitialisation
            const resetForm = document.getElementById('passwordResetForm');
            
            resetForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const email = document.getElementById('resetEmail').value.trim();
                const emailError = document.getElementById('resetEmailError');
                
                // Réinitialiser le message d'erreur
                emailError.style.display = 'none';
                
                // Validation de l'email
                if (!email || !email.includes('@uit.ac.ma')) {
                    emailError.style.display = 'block';
                    return;
                }
                
                // Simulation d'envoi
                const submitBtn = this.querySelector('.submit-btn');
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Envoi en cours...';
                
                setTimeout(() => {
                    alert('Un lien de réinitialisation a été envoyé à ' + email);
                    passwordResetModal.style.display = 'none';
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Envoyer le lien de réinitialisation';
                }, 1500);
            });
            
            // Gestion du bouton Google
            document.querySelector('.google-btn').addEventListener('click', function() {
                alert("Fonctionnalité de connexion Google à implémenter");
            });
        });
