        document.addEventListener('DOMContentLoaded', function() {
            // Gestion de l'affichage des noms de fichiers multiples
            document.getElementById('projectFile').addEventListener('change', function(e) {
                const files = e.target.files;
                let fileNames = 'Aucun fichier sélectionné';
                
                if (files.length > 0) {
                    fileNames = '';
                    for (let i = 0; i < files.length; i++) {
                        if (i > 0) fileNames += ', ';
                        fileNames += files[i].name;
                    }
                }
                
                document.getElementById('projectFileNames').textContent = fileNames;
            });
            
            document.getElementById('projectImage').addEventListener('change', function(e) {
                const fileName = e.target.files[0] ? e.target.files[0].name : 'Aucune image sélectionnée';
                document.getElementById('projectImageName').textContent = fileName;
            });
            
            // Gestion de la soumission du formulaire
            document.getElementById('projectForm').addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Validation
                const projectName = document.getElementById('projectName').value.trim();
                const description = document.getElementById('description').value.trim();
                const category = document.getElementById('category').value;
                const projectType = document.getElementById('projectType').value;
                const supervisor = document.getElementById('supervisor').value;
                const files = document.getElementById('projectFile').files;
                
                if (!projectName || !description || !category || !projectType || !supervisor || files.length === 0) {
                    alert('Veuillez remplir tous les champs obligatoires (*)');
                    return;
                }
                
                // Simulation de soumission
                const submitBtn = this.querySelector('.submit-btn');
                
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Envoi en cours...';
                submitBtn.disabled = true;
                
                setTimeout(() => {
                    alert('Projet soumis avec succès!');
                    this.reset();
                    document.getElementById('projectFileNames').textContent = 'Aucun fichier sélectionné';
                    document.getElementById('projectImageName').textContent = 'Aucune image sélectionnée';
                    submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Soumettre le projet';
                    submitBtn.disabled = false;
                }, 1500);
            });
        });
