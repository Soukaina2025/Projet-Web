// Initialisation du carrousel Swiper
document.addEventListener('DOMContentLoaded', function() {
  const swiper = new Swiper('.swiper', {
      loop: true,
      spaceBetween: 30,
      autoplay: {
          delay: 5000,
          disableOnInteraction: false,
          pauseOnMouseEnter: true,
      },
      pagination: {
          el: '.swiper-pagination',
          clickable: true,
          dynamicBullets: true,
      },
      navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
      },
      breakpoints: {
          0: { slidesPerView: 1 },
          768: { slidesPerView: 2 },
          1024: { slidesPerView: 3 }
      }
  });

  // Masquer tous les sous-menus au chargement
  const submenus = document.querySelectorAll('.submenu');
  submenus.forEach(submenu => {
      submenu.style.display = 'none';
  });

  // Gestion du menu utilisateur
  const toggleButton = document.getElementById('dropdownUser');
  if (toggleButton) {
      toggleButton.addEventListener('click', function(e) {
          e.preventDefault();
          const dropdownMenu = document.querySelector('.dropdown-menu');
          if (dropdownMenu) {
              dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
          }
      });

      // Fermer le menu en cliquant à l'extérieur
      document.addEventListener('click', function(event) {
          const dropdownMenu = document.querySelector('.dropdown-menu');
          if (dropdownMenu && !toggleButton.contains(event.target) && !dropdownMenu.contains(event.target)) {
              dropdownMenu.style.display = 'none';
          }
      });
  }
});

// Fonction pour basculer l'affichage des sous-menus
function toggleMenu(menuId) {
  const submenu = document.getElementById(menuId);
  if (submenu) {
      submenu.style.display = submenu.style.display === 'block' ? 'none' : 'block';
  }
}

new Swiper(".wrapper", {
  loop: true,
  spaceBetween: 30,

  // Autoplay
  autoplay: {
    delay: 5000,
    disableOnInteraction: false,
    pauseOnMouseEnter: true,
  },

  // Pagination bullets
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
    dynamicBullets: true,
  },

  // Navigation arrows
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },

  // Responsive breakpoints
  breakpoints: {
    0: {
      slidesPerView: 1,
    },
    768: {
      slidesPerView: 2,
    },
    1024: {
      slidesPerView: 3,
    },
  },
});
