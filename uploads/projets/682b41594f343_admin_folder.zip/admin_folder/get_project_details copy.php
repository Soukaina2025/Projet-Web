<?php
require_once 'db_config.php';

if (isset($_GET['id'])) {
    $project_id = (int) $_GET['id'];

    try {
        $query = "SELECT p.*, 
                         s.NOM AS student_nom, s.PRENOM AS student_prenom, s.FILIERE, 
                         pr.NOM AS prof_nom, pr.PRENOM AS prof_prenom 
                  FROM project p 
                  JOIN student s ON p.APOGEE = s.APOGEE 
                  JOIN prof pr ON p.ID_PROF = pr.ID_PROF 
                  WHERE p.ID_PROJECT = ?";

        $stmt = $conn->prepare($query);
        $stmt->execute([$project_id]);
        $project = $stmt->fetch();

        if ($project) {
            echo '<div class="row">';
            echo '<div class="col-md-6">';
            echo '<h6>Informations de base</h6>';
            echo '<ul class="list-group list-group-flush mb-3">';
            echo '<li class="list-group-item"><strong>Titre:</strong> ' . htmlspecialchars($project['NOM']) . '</li>';
            echo '<li class="list-group-item"><strong>Type:</strong> ' . htmlspecialchars($project['TYPE']) . '</li>';
            echo '<li class="list-group-item"><strong>Catégorie:</strong> ' . htmlspecialchars($project['CATEGORIE']) . '</li>';
            echo '<li class="list-group-item"><strong>Filière:</strong> ' . htmlspecialchars($project['FILIERE']) . '</li>';
            echo '<li class="list-group-item"><strong>Date de soumission:</strong> ' . date('d/m/Y', strtotime($project['DATE_DEP'])) . '</li>';
            echo '</ul>';

            echo '<h6>Technologies utilisées</h6>';
            echo '<div class="mb-3">' . ($project['TECHNOLOGIE'] ? htmlspecialchars($project['TECHNOLOGIE']) : 'Non spécifié') . '</div>';
            echo '</div>';

            echo '<div class="col-md-6">';
            echo '<h6>Description</h6>';
            echo '<div class="mb-3">' . nl2br(htmlspecialchars($project['DESCRIPTION'])) . '</div>';

            echo '<h6>Fichiers joints</h6>';
            echo '<ul class="list-group">';
            if ($project['FICHIER']) {
                echo '<li class="list-group-item"><a href="uploads/projects/' . htmlspecialchars($project['FICHIER']) . '" target="_blank">Rapport principal</a></li>';
            }
            if ($project['FILE1']) {
                echo '<li class="list-group-item"><a href="uploads/projects/' . htmlspecialchars($project['FILE1']) . '" target="_blank">Fichier supplémentaire 1</a></li>';
            }
            if ($project['FILE2']) {
                echo '<li class="list-group-item"><a href="uploads/projects/' . htmlspecialchars($project['FILE2']) . '" target="_blank">Fichier supplémentaire 2</a></li>';
            }
            if ($project['FILE3']) {
                echo '<li class="list-group-item"><a href="uploads/projects/' . htmlspecialchars($project['FILE3']) . '" target="_blank">Fichier supplémentaire 3</a></li>';
            }
            echo '</ul>';
            echo '</div>';
            echo '</div>';
        } else {
            echo '<div class="alert alert-danger">Projet non trouvé</div>';
        }
    } catch (PDOException $e) {
        echo '<div class="alert alert-danger">Erreur lors de la récupération du projet.</div>';
        error_log("Erreur PDO : " . $e->getMessage());
    }
}
?>
