<?php
session_start();
if (isset($_SESSION['APOGEE'])) {
    header('Location: proj-adm.php');
    exit();
}
$error = $_GET['error'] ?? '';
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion | Espace Administrateur</title>
    
    <!-- Liens CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Header -->
    <header class="header-wrapper bg-white shadow-sm">
        <nav class="navbar navbar-expand-lg navbar-light container">
            <a class="navbar-brand logo" href="../projets_espaces_folder_vf_apropos/index.html">
                <img src="images/ensa_logo.png" alt="Logo ENSA">
            </a>

            <div class="collapse navbar-collapse justify-content-between" id="navbarNav">
                <ul class="navbar-nav nav-links">
                    <li class="nav-item"><a class="nav-link" href="../projets_espaces_folder_vf_apropos/index.html">À propos</a></li>
                    <li class="nav-item"><a class="nav-link" href="../reglements_page_folder_vf/index.html">Règlement</a></li>
                    <li class="nav-item"><a class="nav-link" href="../contact_folder_vf/index.html">Contact</a></li>
                </ul>      
            </div>

            <div class="d-flex align-items-center gap-3 links_container">
                <div class="social_icons">
                    <a href="https://www.instagram.com/ensak.official" class="text-dark" target="_blank"><i class="fab fa-instagram fa-lg"></i></a>
                    <a href="https://ma.linkedin.com/company/ensa-kenitra-official" class="text-dark" target="_blank"><i class="fab fa-linkedin fa-lg"></i></a>
                </div>
                
                <button class="navbar-toggler toggle" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
        </nav>
    </header>



<main class="main-content">
    <div class="login-container">
        <div class="right-side"></div>

        <div class="left-side">
            <div class="form-title">
                <h2>Bienvenue à votre espace admin</h2>
                <p>Accédez à votre compte personnel</p>
            </div>

             <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>

                <form class="form-login" id="studentLoginForm" method="POST" action="login_page_trt.php">
                <div class="form-group">
                        <label for="apogee">ID</label>
                        <div class="input-icon">
                            <i class="fas fa-user"></i>
                            <input type="text" name="apogee" id="apogee" placeholder="Entrez votre ID" required>
                        </div>
                    </div>

                <div class="form-group">
                        <label for="password">Mot de passe</label>
                        <div class="input-icon">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="password" id="password" placeholder="Entrez votre mot de passe" required>
                        </div>
                    </div>

                <button type="submit" class="submit-btn">
                        <i class="fas fa-sign-in-alt"></i> Se connecter
                    </button>

                <div class="form-links">
                    <a href="#" id="forgotPasswordLink"><i class="fas fa-key"></i> Mot de passe oublié ?</a>
                </div>

                <div class="divider">ou</div>

                <button type="button" class="google-btn">
                    <i class="fab fa-google"></i> Se connecter avec Google
                </button>
            </form>
        </div>
    </div>
</main>


    


    <!-- Modal Mot de passe oublié -->
    <div id="passwordResetModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Réinitialisation du mot de passe</h3>
                <span class="close-modal">&times;</span>
            </div>
                <div class="form-group">
                    <label for="resetEmail">Adresse email de recupération</label>
                    <div class="input-icon">
                        <i class="fas fa-envelope"></i>
                        <input type="email" id="resetEmail" required>
                    </div>
                    <div class="error-message" id="resetEmailError">Veuillez entrer une adresse email de récuperation</div>
                </div>
                
                <button type="submit" class="submit-btn">
                    <i class="fas fa-paper-plane"></i> Envoyer le lien de réinitialisation
                </button>
                
                <div class="text-center" style="margin-top: 20px; font-size: 0.9rem;">
                    <p>Un lien vous sera envoyé par email pour réinitialiser votre mot de passe.</p>
                </div>
            </form>
        </div>
    </div>






        <!-- Footer -->
    <footer class="footer-wrapper">
        <div class="footer-section">
          <div class="footer-info">
            <img src="images/LOGO-ENSA.png" alt="Logo ENSA">
            <p><a href="https://ensa.uit.ac.ma/" target="_blank" style="color: white; ">Visiter le site officiel</a></p>
          </div>
          <div class="footer-links">
            <h3>Liens utiles</h3>
            <ul>
                
              <li><a href="../projets_espaces_folder_vf_apropos/index.html">À propos</a></li>
              <li><a href="../reglements_page_folder_vf/index.html">Règlement</a></li>
              <li><a href="../contact_folder_vf/index.html">Contact</a></li>
            </ul>
          </div>
          <div class="footer-contact">
            <h3>Réseaux Sociaux</h3>
            <div class="footer_icons">
                <a target="_blank" href="https://www.instagram.com/ensak.official" class="text-dark"><i class="fab fa-instagram fa-lg"></i></a>
                <a target="_blank" href="https://ma.linkedin.com/company/ensa-kenitra-official" class="text-dark"><i class="fab fa-linkedin fa-lg"></i></a>
            </div>
              
            <a class="contact_link" href="../contact_folder_vf/index.html">Contactez-nous</a>
            <p>(+212) 5 37 37 67 65</p>
            <p>Campus universitaire, BP 241, Kénitra – Maroc</p>
          </div>
        </div>
        <div class="footer-bottom">
          <p>École Nationale des Sciences Appliquées © 2025 Université Ibn Tofail. All Rights Reserved.</p>
        </div>
      </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <script src="script.js"></script>
</body>
</html>